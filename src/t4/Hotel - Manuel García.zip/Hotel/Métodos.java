package T4.Hotel;

/**
 *
 * @author Manuel
 */
public interface M�todos {
    
    void setDatosDelHotel();
}
