package T4.Hotel;

/**
 *
 * @author Manuel
 */
public class HIndividual extends Habitaci�n {
    
    public HIndividual(int n, String es, String t, double p, int nc, int ns, int nb, int nl, int e) {
        super(n, es, t, p, nc, ns, nb, nl, e);
    }
    
    @Override
    public String toString() {
        return super.toString();
    }
}
