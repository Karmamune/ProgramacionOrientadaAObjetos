package T4.Hotel;

/**
 *
 * @author Manuel
 */
public class DatosDelHotel implements M�todos{
    
    @Override
    public void setDatosDelHotel(){
        
    }
}
